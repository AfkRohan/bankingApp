<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	  
  <title>Transactions History</title>
</head>  
<nav class="login">
       <ul>      
    <li> <a href="../app/index.html"><img src="../app/logo/bank.png" alt="logo" id="logo"></a>
    </li></ul>
        <ul class="nbar">
    <li><a href="../app/dashboard.php">Dashboard</a></li>
      <li>
          <a href="../app/withdraw.html">Withdraw/Deposit</a>
        </li>
      <li>
        <a href="../app/signup.html">Sign up</a>
      </li>    
     
      <li>
          <a href="../app/login.html">LogOut</a>
        </li>
    </ul>

    </nav>
<body>
    <div class="container">
<?php 
include "php/connect.php";
$accno = $_POST['accno'];
?>

<div class="content" class="deposits">

<h1 id ="titel"> Deposits </h1>
    <ul>
        <?php
        // Fetch deposits related to the account number selected;
         $result = $mysqli->query("select * from deposits where accounts_account_number='$accno';");
         if($result==true){
         while( $row = mysqli_fetch_array($result)){
         ?>
        <li class="card">
            <?php
            echo "<h4>".$row['deposittime']."</h4>";
           
            echo "<h4>".$row['amount']."</h4>";
            ?>
        </li>
        <?php } } 
        ?>
    </ul>
</div>


<div class="content" class="withdrawls">
<h1 id ="titel2"> Withdrawls </h1>
    <ul>
        <?php
        // Fetch withdrawls related to the account number selected;
         $result = $mysqli->query("select * from withdraw where accounts_account_number='$accno';");
         if($result==true){
         while( $row = mysqli_fetch_array($result)){
         ?>
        <li class="card">
            <?php
            echo "<h4>".$row['withdrawltime']."</h4>";
            echo "<h4>".$row['amount']."</h4>";
            ?>
        </li>
        <?php } } ?>
    </ul>
</div></div>
<footer>
<input id="pi_input" type="range" min="10" max="30" value="16px" step="1" />
    <p>Fontsize: <output id="value"></output></p>
    <script>
    const value = document.querySelector("#value")
    const input = document.querySelector("#pi_input")
    value.textContent = input.value
    input.addEventListener("input", (event) => {
    value.textContent = event.target.value;
    document.querySelector('html').style.setProperty('font-size',`${input.value}px`);
    })
    </script>
    <div id="social_icon">
        <a href="#" class="fa fa-youtube"></a>
		<a href="#" class="fa fa-facebook"></a>
	    <a href="#" class="fa fa-instagram"></a>
	    <a href="#" class="fa fa-pinterest"></a>
        <a href="#" class="fa fa-envelope"></a>
	</div>
       
    <p> &copy; RoyalfriendBank 2023 </p>
    <p> Terms and conditions / Privacy Policy </p>
   </footer>
    </body>
    </html>