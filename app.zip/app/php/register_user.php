<?php 
include "connect.php";
$cif = uniqid();
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$password = $_POST['upassword'];
$email = $_POST['uemail'];
$phone = $_POST['phone'];
$add_id = uniqid("A");
$address1 = $_POST['address1'];
$unitnum = " ";
$inputCity = $_POST['inputCity'];
$pincode = $_POST['inputZip'];
$province = $_POST['province'];
$address9 = explode(" ",$address1,2);
$country = 'Canada';
$street_num = intval($address9[0]);

// Insert into cellnumbers
$sql3 = "INSERT INTO cellnumbers  VALUES
($phone, 'Mobile', '+1');";


$phone_exists  = $mysqli->query("select * from cellnumbers where cellnumber = '$phone' ;") or die();
// Insert into address
$sql2 = " INSERT INTO address VALUES
('$street_num', '$unitnum', '$address9[1]', '$inputCity', '$province','$country',
'$pincode', '$add_id');";


if(is_null($phone_exists) === false){
  // Do nothing
}
else{
if($mysqli->query($sql3) === TRUE) {
  //
} else {
  ?>
      <script>
        alert("Incorrect Phone number");
        window.location.href = "../signup.html"
      </script>
      <?php
  }
}

$address_exists = $mysqli->query("select * from address where street_name = '$address9[1]' and pin_code = '$pincode';") or die();
if(is_null($address_exists) === false){
  $add_id=$address_exists->fetch_assoc()['address_id'];
} 
else{
if($mysqli->query($sql2) === TRUE) {
    //
  } else {
    ?>
        <script>
          alert("Incorrect Address");
        window.location.href = "../signup.html"
      </script>
      <?php
    
  }
}


// Insert into customers
$sql = "INSERT INTO customers (CIF, first_name, last_name, 
password, cellnumbers_cellnumber, address_address_id, email_address)
VALUES 
('$cif', '$firstname', '$lastname', '$password', '$phone', '$add_id','$email');";
  if($mysqli->query($sql) === TRUE) {
    $mysqli->close();

    // Start Session
    session_start();
    $_SESSION["cif"] = $cif;
    ?>
    <script>
      window.location.href = "../dashboard.php";
    </script>
    <?php
  } else {
    ?>
        <script>
        alert("Something went wrong");
        window.location.href = "../signup.html"
      </script>
      <?php
  }  
  
?>
