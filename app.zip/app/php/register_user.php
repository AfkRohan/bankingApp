<!-- 
Foram Patel (8844689)
Rohan Shah (8847495) 
-->

<?php 
include "city.php";
include "connect.php";
$cif = uniqid();
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$password = $_POST['upassword'];
$re_password = $_POST['reupassword'];
$email = $_POST['uemail'];
$phone = str_ireplace("-","",$_POST['phone']);
$add_id = uniqid("A");
$address1 = $_POST['address1'];
$unitnum = " ";
$inputCity = $_POST['inputCity'];
$pincode = str_ireplace(" ","",$_POST['inputZip']);
$province = $_POST['province'];
$address9 = explode(" ",$address1,2);
$country = 'Canada';
$street_num = intval($address9[0]);
$flag = true;
$expression = '/^([a-zA-Z]\d[a-zA-Z])\ {0,1}(\d[a-zA-Z]\d)$/';

if($password!==$re_password){
  $flag = false;
  echo '<p> Password does not match </p>';
}
if(!(bool)preg_match($expression, $pincode)){
  $flag = false;
  echo'<p>invalid postal code</p>';
}
$provinceandcities = $cities[$province];
if(!in_array($inputCity,$provinceandcities)){
  $flag=false;
  echo 'Cities doed not match the province.';
  
}
if($flag===true){   
// Insert into cellnumbers
$sql3 = "INSERT INTO cellnumbers  VALUES
($phone, 'Mobile', '+1');";

$phone_exists  = $mysqli->query("select * from cellnumbers where cellnumber = '$phone' ;") or die();

if(($phone_exists->num_rows>0)){
  echo "phone exists";
}
else{
if($mysqli->query($sql3) === TRUE) {
  //
} else {
  ?>
      <script>
        alert("Incorrect Phone number");
        window.location.href = "../signup.html"
      </script>
      <?php
  }
}
// Insert into address
$sql2 = " INSERT INTO address VALUES
('$street_num', '$unitnum', '$address9[1]', '$inputCity', '$province','$country',
'$pincode', '$add_id');";

$address_exists = $mysqli->query("select * from address where street_name = '$address9[1]' and pin_code = '$pincode';") or die();
if(($address_exists->num_rows)>0){
  $add_id=(($address_exists->fetch_assoc())[0])['address_id'];
} 
else{
if($mysqli->query($sql2) === TRUE) {
    //
  } else {

    ?>
        <script>
          alert("Incorrect Address");
        window.location.href = "../signup.html"
      </script>
      <?php
    
  }
}


// Insert into customers
$sql = "INSERT INTO customers (CIF, first_name, last_name, 
password, cellnumbers_cellnumber, address_address_id, email_address)
VALUES 
('$cif', '$firstname', '$lastname', '$password', '$phone', '$add_id','$email');";
  if($mysqli->query($sql) === TRUE) {
    $mysqli->close();
     
    // Start Session
    session_start();
    $_SESSION["cif"] = $cif;
    ?>
    <script>
      window.location.href = "../dashboard.php";
    </script>

    <?php
      }
   else {
    ?>
        <script>
        alert("Something went wrong");
        window.location.href = "../signup.html"
      </script>
      <?php
  }  
}
?>
