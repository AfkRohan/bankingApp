<?php 
include "connect.php";
$uemail = $_POST['fpemail'];
$upassword = $_POST['fpPass'];

$sql = "UPDATE Customers SET password='$upassword' WHERE email_address='$uemail'";

if ($mysqli->query($sql) === TRUE) {
?>
<script>
 window.location.href = "../../app/login.html"
</script>
<?php
} else {
  ?>
  <script>
  alert("Something went wrong!!")
   window.location.href = "../../app/login.html"
  </script>
  <?php
}
?>