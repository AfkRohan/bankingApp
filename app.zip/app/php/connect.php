<!-- 
Foram Patel (8844689)
Rohan Shah (8847495) 
-->

<?php
$host="localhost:3306";
$username="root";
$pass="";
$db="rf2_banksystem";

$mysqli = new mysqli($host,$username,$pass,$db) or die();
// Check connection
if ($mysqli -> connect_errno) {
  echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  exit();
}
?>