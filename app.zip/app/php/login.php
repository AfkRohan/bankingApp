<!-- 
Foram Patel (8844689)
Rohan Shah (8847495) 
-->

<?php 
include "connect.php";
$uemail = $_POST['uemail'];
$upassword = $_POST['upassword'];

// check if user exists or not
$result = $mysqli->query("select * from customers where email_address='$uemail' and password='$upassword'");
// START SESSION 
if($result->num_rows > 0){
    $CIF = $result->fetch_assoc()['CIF'];
    session_start();
    $_SESSION['cif']=$CIF;
?>
<!-- Redirect for valid input -->
<script>
window.location.href = "../../app/dashboard.php"
</script>
<?php
}
// invalid password or username stay on same page
else{
?>
<script>
alert("Incorrect Username or password");
window.location.href = "../../app/login.html"
</script>
<?php
}
?>