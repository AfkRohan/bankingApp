<?php
include "connect.php";
$account_type = $_POST['Account'];
$tid = uniqid("d");
$account_num = $_POST['Account_num'];
$amount = intval($_POST['Amount']);
$transaction_type = $_POST['gridRadios'];
$time = date('Y-m-d h:i:s');
if($transaction_type=='Deposit'){
    $sql = "INSERT INTO `deposits` (`depositID`, `deposittime`, `amount`, `accounts_account_number`) VALUES
    ('$tid', '$time','$amount' , '$account_num');";
    if($mysqli->query($sql) === TRUE) {
        ?>
        <script>
          window.location.href = "../dashboard.php"
        </script>
        <?php
      } else {
        ?>
        <script>
        window.location.href = "../withdraw.html"
      </script>
      <?php
    }
}
else {
    $sql = "INSERT INTO `withdraw` (`withdrawlID`, `withdrawltime`, `amount`, `accounts_account_number`) VALUES
    ('$tid', '$time','$amount' , '$account_num');";
    if($mysqli->query($sql) === TRUE) {
      ?>
      <script>
        window.location.href = "../withdraw.html"
      </script>
      <?php
      } else {
        ?>
        <script>
        alert("Insufficient balance");
        window.location.href = "../withdraw.html"
      </script>
      <?php
    }
}
?>