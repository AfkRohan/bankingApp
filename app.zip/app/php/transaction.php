<!-- 
Foram Patel (8844689)
Rohan Shah (8847495) 
-->
<?php
include "connect.php";
$account_num = $_POST['Account_num'];
$amount = intval($_POST['Amount']);
$transaction_type = $_POST['gridRadios'];
$time = date('Y-m-d h:i:s');
session_start();
$cif = $_SESSION['cif'];
$result = $mysqli->query("select `account_number` from accounts where `customers_CIF` = '$cif' ;") or die();
$user_accounts = $result->fetch_assoc();
if(in_array($account_num,$user_accounts)){
if($transaction_type=='Deposit'){
  $tid = uniqid("d");
    $sql = "INSERT INTO `deposits` (`depositID`, `deposittime`, `amount`, `accounts_account_number`) VALUES
    ('$tid', '$time','$amount' , '$account_num');";
    if($mysqli->query($sql) === TRUE) {
        ?>
        <script>
          window.location.href = "../dashboard.php"
        </script>
        <?php
      } else {
        ?>
        <script>
        window.location.href = "../withdraw.html"
      </script>
      <?php
    }
}
else {
  $tid = uniqid("w");
    $sql = "INSERT INTO `withdraw` (`withdrawlID`, `withdrawltime`, `amount`, `accounts_account_number`) VALUES
    ('$tid', '$time','$amount' , '$account_num');";
    if($mysqli->query($sql) === TRUE) {
      ?>
      <script>
        window.location.href = "../withdraw.html"
      </script>
      <?php
      } else {
        ?>
        <script>
        alert("Insufficient balance");
        window.location.href = "../withdraw.html"
      </script>
      <?php
    }
}
}
else {
  ?>
  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
</head>   
<body>
  <h1> This account does not belong to you! Please enter a valid account number </h1>
  <p id="msg">
  <a href="../withdraw.html">Try Again</a>
  </p>
</body>
</html>
  <?php
}
?>