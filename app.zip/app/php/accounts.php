<?php
include 'connect.php';
$balance = intval($_POST['balance']);
$cif = $_POST['cif'];
$type = $_POST['Account'];
$date_created = date('Y-m-d h:i:s');
$acc_num = uniqid('AC');
$status = 'Active';
// Insert data from form to the database
$sql = "INSERT INTO `accounts` (`account_number`, `balance`, `date_created`, `status`, `accounttype`, `customers_CIF`) VALUES
('$acc_num', '$balance', '$date_created', '$status', '$type', '$cif');";
if($mysqli->query($sql) === TRUE) {
    ?>
    <script>
    alert("New record created successfully");
     window.location.href="../accounts.html";
    </script>
    <?php
  } else {
    echo "Error: " . $sql . "<br>" . $mysqli->error;
  }
?>