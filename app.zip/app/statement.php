<?php 
include "php/connect.php";
include_once('fpdf184/fpdf.php');
$accno = $_POST['accno'];
// Fetch account number for querying using hidden input fields

class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo    
	$this->Image('logo/bank.png',90,10,50);
	$this->Ln(35);
    $this->SetFont('Arial','B',13);
}

// Page footer
function Footer()
{
    // Position at 1.5 cm from bottom
    $this->SetY(-45);
    // Arial italic 8
    $this->SetFont('Arial','I',8);
    // Page number
    $this->Cell(0,10,'Page '.$this->PageNo().'/{nb}',0,0,'C');
}
}

$heading = ['withdrawltime','amount'];
$result = $mysqli->query("select * from deposits where accounts_account_number='$accno';");

$pdf = new PDF();
$addpage = 0;
foreach($result as $row) {
//header
$pdf->AddPage();
$pdf->Cell(80);
$pdf->Cell(30,50,'Deposit',0,1,'C');
//footer page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',16);

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
// body 
$addpage=$addpage+1;
$temp=0;
foreach($row as $column){
    $pdf->cell(20);
    if ($temp==1){
        $pdf->cell(30,-20,"Deposit time: ",0);
        $pdf->cell(90,-20,$column,0);
    }
    else if($temp==2){
        $pdf->Ln();
        $pdf->cell(40);
        $pdf->cell(30,20,"Amount Added",0,0);
        $pdf->cell(75,20,$column,0,0);
    }
    $temp++;
}
$pdf->Ln();
}
// Withdrawl
$result = $mysqli->query("select * from withdraw where accounts_account_number='$accno';");

foreach($result as $row) {
//header
$pdf->AddPage();
$pdf->Cell(80);
$pdf->Cell(30,50,'Withdrawl',0,1,'C');
//footer page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',16);

$pdf->SetFont('Arial','B',10);
$pdf->Ln();
// body 
$addpage=$addpage+1;
$temp=0;
foreach($row as $column){
    $pdf->cell(20);
    if ($temp==1){
        $pdf->cell(30,-20,"Withdrawl time: ",0);
        $pdf->cell(90,-20,$column,0);
    }
    else if($temp==2){
        $pdf->Ln();
        $pdf->cell(40);
        $pdf->cell(30,20,"Withdrawl",0,0);
        $pdf->cell(75,20,$column,0,0);
    }
    $temp++;
}
$pdf->Ln();
}
$pdf->Output()

?>