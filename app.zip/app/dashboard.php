<!-- 
Foram Patel (8844689)
Rohan Shah (8847495) 
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <link rel="stylesheet" href="style.css">  
  <title>Dashboard</title>
</head>

<nav class="login">
       <ul>      
    <li> <a href="../app/index.html"><img src="../app/logo/bank.png" alt="logo" id="logo"></a>
    </li></ul>
        <ul class="nbar">
    <li><a href="../app/dashboard.php">Dashboard</a></li>
      <li>
          <a href="../app/withdraw.html">Withdraw/Deposit</a>
        </li>
      <li>
        <a href="../app/signup.html">Sign up</a>
      </li>         
      <li>
          <a href="../app/login.html">LogOut</a>
        </li>
    </ul>
    </nav>
<body>
    <h1>Your accounts</h1>
    <div>
    <?php 
    // including connection file
    include "php/connect.php";
    // starting a sesssion
    session_start();
    // fetching authentication key from a session
    $CIF = $_SESSION['cif'];
    // Fetching and displaying all  accounts related to the logged in user;
    $result = $mysqli->query("select * from accounts where customers_CIF='$CIF';");
    if(($result->num_rows)>0){
    while( $row = mysqli_fetch_array($result)){
    ?>
    <div class="accounts">
        <?php 
        $accnum = $row['account_number'];
        $accdisp = $accnum;
        echo "<h2>".$row['accounttype']."</h2>";  
        echo "<h3>".$row['status']."</h3>";
        echo "<h2>".$accdisp."</h2>";
        echo "<p>".$row['balance']."CAD</p>";
        ?>
        <div class="btnclass">
        <!-- View history -->
        <form method="post" action="trans_history.php"> 
            <input type="hidden"  name="accno" value="<?php echo $accnum; ?>">
            <button type="submit" class="btn btn-success" formaction="trans_history.php"> View account history</button> 
        </form>
        <!-- Generate pdf -->
        <form method="post" action="statement.php"> 
            <input type="hidden"  name="accno" value="<?php echo $accnum; ?>">
            <button type="submit" class="btn btn-success"> Get bank statement</button> 
        </form>
        </div>
    </div>
    <?php
    }
    }
    else{
        ?>
        <h2>  Please go the accounts page to create account with some intial deposits for this demo. </h2>
        <p> Your CIF is  <?php
        echo(substr($CIF,0,11));
        ?> </p>
        <p> <a href="../app/accounts.html"> Click here to create an account </a> </p>
        <?php
    }
    ?>
    </div>
    <footer>
    <input id="pi_input" type="range" min="16" max="32" step="0.5" />
    <p>Value: <output id="value"></output></p>
    <script>
    const value = document.querySelector("#value")
    const input = document.querySelector("#pi_input")
    value.textContent = input.value
    input.addEventListener("input", (event) => {
    value.textContent = event.target.value
    document.body.style.fontSize = value;
    })
    </script>
    <div id="social_icon">
        <a href="#" class="fa fa-youtube"></a>
		<a href="#" class="fa fa-facebook"></a>
	<a href="#" class="fa fa-instagram"></a>
	<a href="#" class="fa fa-pinterest"></a>
    <a href="#" class="fa fa-envelope"></a>
	</div>
      
  <p> &copy; RoyalfriendBank 2023 </p>
           <p> Terms and conditions / Privacy Policy </p>
   </footer>
    </body>
    </html>
</body>

</html>

